package loginEmprestimo;

public class Categoria {
    private String nmCategoria;

    // construtor
    public Categoria(String nmCategoria) {
        this.nmCategoria = nmCategoria;
    }

    // getters and setters
    public String getNmCategoria() {
        return nmCategoria;
    }

    public void setNmCategoria(String nmCategoria) {
        this.nmCategoria = nmCategoria;
    }
}
